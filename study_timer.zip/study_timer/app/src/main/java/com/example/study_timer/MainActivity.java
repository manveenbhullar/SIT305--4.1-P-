package com.example.study_timer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import static android.widget.Toast.makeText;

public class MainActivity extends AppCompatActivity {

    Chronometer chronometer;
    boolean run, hold;
    long time, pauseOffSet, stopOffSet;
    TextView text1, text2;
    EditText editText;
    String timer, current, constant, ticker;
    SharedPreferences sharedPreferences1, sharedPreferences2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chronometer = findViewById(R.id.chronometer);
        text1 = findViewById(R.id.text1);
        text2 = findViewById(R.id.texts2);
        editText = findViewById(R.id.editText);

        sharedPreferences1 = getSharedPreferences("com.example.41PASS", MODE_PRIVATE);
        sharedPreferences2 = getSharedPreferences("com.example.41PAS", MODE_PRIVATE);
        checkSharedPreferences();
    }


    public void playChronometer(View v){
        if (editText.getText().toString().isEmpty())
        {
            makeText(this, "Please add the name of the study type", Toast.LENGTH_LONG).show();
        }

        else
        {
            if(!run){
                chronometer.setBase(SystemClock.elapsedRealtime()- pauseOffSet);
                chronometer.start();
                time = SystemClock.elapsedRealtime() - pauseOffSet;
                run = true;
            }
        }

    }

    public void pauseChronometer(View v){

        if(run){
            chronometer.stop();
            pauseOffSet = SystemClock.elapsedRealtime()-chronometer.getBase();
            run = false;
            hold = false;
        }
    }

    public void endChronometer(View v){

        if(run){
            chronometer.stop();
            stopOffSet = SystemClock.elapsedRealtime()-chronometer.getBase();
            long seconds = (stopOffSet /1000) % 60;
            long minutes = (stopOffSet /1000)/60;
            long hours = (stopOffSet /1000)/3600;
            timer = String.format("%02d:%02d:%02d",hours,minutes,seconds);
            run = false;
        }
        else
        {
            if(!hold)
            {
                long second = (pauseOffSet /1000) % 60;
                long minute = (pauseOffSet /1000)/60;
                long hour = (pauseOffSet /1000)/3600;
                timer =  String.format("%02d:%02d:%02d",hour,minute,second);
                hold = true;
            }

        }
        chronometer.setBase(SystemClock.elapsedRealtime());
        pauseOffSet = 0;
        run = false;
        stopOffSet = 0;
        text1.setText("You spent "+ timer +" on " + editText.getText().toString() + " last time");

        SharedPreferences.Editor editor1 = sharedPreferences1.edit();
        SharedPreferences.Editor editor2 = sharedPreferences2.edit();
        editor1.putString(constant, editText.getText().toString());
        editor2.putString(ticker, timer);
        editor1.apply();
        editor2.apply();

    }

    public void checkSharedPreferences()
    {
        String usrn = sharedPreferences1.getString(constant,"");
        String previous_turn = sharedPreferences2.getString(ticker,"");
        text1.setText("You spent "+ previous_turn +" on " + usrn + " last time");
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putLong("time", pauseOffSet);
        outState.putBoolean("running", run);
        outState.putLong("current",time);
        outState.putString("name",editText.getText().toString());



    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        pauseOffSet = savedInstanceState.getLong("time");
        run = savedInstanceState.getBoolean("running");
        time = savedInstanceState.getLong("current");
        current = savedInstanceState.getString("name");

        if(run)
        {
            chronometer.setBase(time);
            chronometer.start();
        }

        if (!run)
        {
            long second = (pauseOffSet /1000) % 60;
            long minute = (pauseOffSet /1000)/60;
            long hour = (pauseOffSet /1000)/3600;
            if (pauseOffSet < 360000)
            {
                chronometer.setText(String.format("%02d:%02d",minute,second));

            }

            else
            {
                chronometer.setText(String.format("%02d:%02d:%02d",hour,minute,second));
            }
        }


    }
}